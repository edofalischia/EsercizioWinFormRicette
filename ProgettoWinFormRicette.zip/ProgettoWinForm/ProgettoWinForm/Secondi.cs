﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgettoWinForm
{
    public partial class Secondi : Form
    {
        private Form1 form1;
        public Secondi(Form1 form1)
        {
            InitializeComponent();
            var nomiSecondi = NuovaRicetta.FiltraNomiRicette(NuovaRicetta.OttieniRicette().Where(r => r.Categoria == "Secondi piatti").ToList());
            foreach (var nome in nomiSecondi)
            {
                if (!listBoxSecondi.Items.Contains(nome))
                {
                    listBoxSecondi.Items.Add(nome);
                }
            }
            this.form1 = form1;
            form1.Visible= false;
        }

        private void buttonMostraSecondi_Click(object sender, EventArgs e)
        {
            if (listBoxSecondi.SelectedItem is string nomeRicettaSelezionata)
            {
                var ricette = NuovaRicetta.OttieniRicette();
                var ricettaSelezionata = ricette.FirstOrDefault(r => r.Nome == nomeRicettaSelezionata);
                if (ricettaSelezionata != null)
                {
                    richTextBoxSecondi.Clear();
                    richTextBoxSecondi.AppendText(ricettaSelezionata.ToString());
                }
                else
                {
                    MessageBox.Show("Ricetta non trovata.");
                }
            }
            else
            {
                MessageBox.Show("Seleziona una ricetta.");
            }
        }

        private void btn_chiudi_Click(object sender, EventArgs e)
        {
            this.Close();
            form1.Visible = true;
        }
    }
}
