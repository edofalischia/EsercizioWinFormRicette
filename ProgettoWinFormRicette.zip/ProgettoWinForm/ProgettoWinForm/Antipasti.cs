﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgettoWinForm
{
    public partial class Antipasti : Form
    {
        private Form1 form1;
        public Antipasti(Form1 form1)
        {
            InitializeComponent();
            var nomiAntipasti = NuovaRicetta.FiltraNomiRicette(NuovaRicetta.OttieniRicette().Where(r => r.Categoria == "Antipasti").ToList());
            foreach (var nome in nomiAntipasti)
            {
                listBoxAntipasti.Items.Add(nome);
            }

            this.form1 = form1;
            form1.Visible = false;
        }

        private void Antipasti_Load(object sender, EventArgs e)
        {

        }

        private void buttonMostraAntipasto_Click(object sender, EventArgs e)
        {
            if (listBoxAntipasti.SelectedItem is string nomeRicettaSelezionata)
            {
                var ricette = NuovaRicetta.OttieniRicette();
                var ricettaSelezionata = ricette.FirstOrDefault(r => r.Nome == nomeRicettaSelezionata);
                if (ricettaSelezionata != null)
                {
                    richTextBoxAntipasti.Clear();
                    richTextBoxAntipasti.AppendText(ricettaSelezionata.ToString());
                }
                else
                {
                    MessageBox.Show("Ricetta non trovata.");
                }
            }
            else
            {
                MessageBox.Show("Seleziona una ricetta.");
            }
        }

        private void btn_chiudi_Click(object sender, EventArgs e)
        {
            this.Close();
            form1.Visible = true;
        }
    }
}
