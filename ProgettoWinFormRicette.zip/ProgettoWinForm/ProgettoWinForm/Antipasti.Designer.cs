﻿namespace ProgettoWinForm
{
    partial class Antipasti
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            panel2 = new Panel();
            label2 = new Label();
            label1 = new Label();
            btn_chiudi = new Button();
            richTextBoxAntipasti = new RichTextBox();
            listBoxAntipasti = new ListBox();
            buttonMostraAntipasto = new Button();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Tan;
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(890, 74);
            panel1.TabIndex = 8;
            // 
            // panel2
            // 
            panel2.BackColor = Color.IndianRed;
            panel2.Controls.Add(label2);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(890, 74);
            panel2.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Comic Sans MS", 36F, FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(304, 0);
            label2.Name = "label2";
            label2.Size = new Size(342, 68);
            label2.TabIndex = 1;
            label2.Text = "Le tue ricette";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("SimSun", 18F, FontStyle.Italic, GraphicsUnit.Point);
            label1.Location = new Point(429, 24);
            label1.Name = "label1";
            label1.Size = new Size(94, 24);
            label1.TabIndex = 1;
            label1.Text = "ricette";
            // 
            // btn_chiudi
            // 
            btn_chiudi.BackColor = Color.Bisque;
            btn_chiudi.FlatStyle = FlatStyle.Flat;
            btn_chiudi.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btn_chiudi.Location = new Point(196, 420);
            btn_chiudi.Name = "btn_chiudi";
            btn_chiudi.Size = new Size(74, 66);
            btn_chiudi.TabIndex = 12;
            btn_chiudi.Text = "Chiudi";
            btn_chiudi.UseVisualStyleBackColor = false;
            btn_chiudi.Click += btn_chiudi_Click;
            // 
            // richTextBoxAntipasti
            // 
            richTextBoxAntipasti.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            richTextBoxAntipasti.Location = new Point(357, 105);
            richTextBoxAntipasti.Name = "richTextBoxAntipasti";
            richTextBoxAntipasti.Size = new Size(503, 368);
            richTextBoxAntipasti.TabIndex = 9;
            richTextBoxAntipasti.Text = "";
            // 
            // listBoxAntipasti
            // 
            listBoxAntipasti.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            listBoxAntipasti.FormattingEnabled = true;
            listBoxAntipasti.ItemHeight = 19;
            listBoxAntipasti.Location = new Point(86, 105);
            listBoxAntipasti.Name = "listBoxAntipasti";
            listBoxAntipasti.Size = new Size(155, 289);
            listBoxAntipasti.TabIndex = 10;
            // 
            // buttonMostraAntipasto
            // 
            buttonMostraAntipasto.BackColor = Color.Bisque;
            buttonMostraAntipasto.FlatStyle = FlatStyle.Flat;
            buttonMostraAntipasto.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            buttonMostraAntipasto.Location = new Point(63, 420);
            buttonMostraAntipasto.Name = "buttonMostraAntipasto";
            buttonMostraAntipasto.Size = new Size(74, 66);
            buttonMostraAntipasto.TabIndex = 11;
            buttonMostraAntipasto.Text = "Mostra ricetta";
            buttonMostraAntipasto.UseVisualStyleBackColor = false;
            buttonMostraAntipasto.Click += buttonMostraAntipasto_Click;
            // 
            // Antipasti
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.OldLace;
            ClientSize = new Size(890, 508);
            Controls.Add(btn_chiudi);
            Controls.Add(buttonMostraAntipasto);
            Controls.Add(listBoxAntipasti);
            Controls.Add(richTextBoxAntipasti);
            Controls.Add(panel1);
            Name = "Antipasti";
            Text = "Antipasti";
            Load += Antipasti_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private RichTextBox richTextBoxAntipasti;
        private ListBox listBoxAntipasti;
        private Button buttonMostraAntipasto;
        private Button btn_chiudi;
        private Panel panel2;
        private Label label2;
    }
}