﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgettoWinForm
{
    public partial class Dolci : Form
    {
        private Form1 form1;
        public Dolci(Form1 form1)
        {
            InitializeComponent();
            var nomiDolci = NuovaRicetta.FiltraNomiRicette(NuovaRicetta.OttieniRicette().Where(r => r.Categoria == "Dolci").ToList());
            foreach (var nome in nomiDolci)
            {
                if (!listBoxDolci.Items.Contains(nome))
                {
                    listBoxDolci.Items.Add(nome);
                }
            }
            this.form1 = form1;
            form1.Visible = false;
        }

        private void buttonMostraDolci_Click(object sender, EventArgs e)
        {
            if (listBoxDolci.SelectedItem is string nomeRicettaSelezionata)
            {
                var ricette = NuovaRicetta.OttieniRicette();
                var ricettaSelezionata = ricette.FirstOrDefault(r => r.Nome == nomeRicettaSelezionata);
                if (ricettaSelezionata != null)
                {
                    richTextBoxDolci.Clear();
                    richTextBoxDolci.AppendText(ricettaSelezionata.ToString());
                }
                else
                {
                    MessageBox.Show("Ricetta non trovata.");
                }
            }
            else
            {
                MessageBox.Show("Seleziona una ricetta.");
            }
        }

        private void btn_chiudi_Click(object sender, EventArgs e)
        {
            this.Close();
            form1.Visible=true;
        }
    }
}
