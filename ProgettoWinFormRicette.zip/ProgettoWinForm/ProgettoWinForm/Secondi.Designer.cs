﻿namespace ProgettoWinForm
{
    partial class Secondi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_chiudi = new Button();
            buttonMostraSecondi = new Button();
            listBoxSecondi = new ListBox();
            richTextBoxSecondi = new RichTextBox();
            panel1 = new Panel();
            panel2 = new Panel();
            label2 = new Label();
            label1 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // btn_chiudi
            // 
            btn_chiudi.BackColor = Color.Bisque;
            btn_chiudi.FlatStyle = FlatStyle.Flat;
            btn_chiudi.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btn_chiudi.Location = new Point(170, 420);
            btn_chiudi.Name = "btn_chiudi";
            btn_chiudi.Size = new Size(74, 66);
            btn_chiudi.TabIndex = 20;
            btn_chiudi.Text = "Chiudi";
            btn_chiudi.UseVisualStyleBackColor = false;
            btn_chiudi.Click += btn_chiudi_Click;
            // 
            // buttonMostraSecondi
            // 
            buttonMostraSecondi.BackColor = Color.Bisque;
            buttonMostraSecondi.FlatStyle = FlatStyle.Flat;
            buttonMostraSecondi.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            buttonMostraSecondi.Location = new Point(33, 420);
            buttonMostraSecondi.Name = "buttonMostraSecondi";
            buttonMostraSecondi.Size = new Size(74, 66);
            buttonMostraSecondi.TabIndex = 19;
            buttonMostraSecondi.Text = "Mostra ricetta";
            buttonMostraSecondi.UseVisualStyleBackColor = false;
            buttonMostraSecondi.Click += buttonMostraSecondi_Click;
            // 
            // listBoxSecondi
            // 
            listBoxSecondi.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            listBoxSecondi.FormattingEnabled = true;
            listBoxSecondi.ItemHeight = 19;
            listBoxSecondi.Location = new Point(60, 105);
            listBoxSecondi.Name = "listBoxSecondi";
            listBoxSecondi.Size = new Size(155, 289);
            listBoxSecondi.TabIndex = 18;
            // 
            // richTextBoxSecondi
            // 
            richTextBoxSecondi.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            richTextBoxSecondi.Location = new Point(331, 105);
            richTextBoxSecondi.Name = "richTextBoxSecondi";
            richTextBoxSecondi.Size = new Size(503, 368);
            richTextBoxSecondi.TabIndex = 17;
            richTextBoxSecondi.Text = "";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Tan;
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(876, 74);
            panel1.TabIndex = 21;
            // 
            // panel2
            // 
            panel2.BackColor = Color.IndianRed;
            panel2.Controls.Add(label2);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(876, 74);
            panel2.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Comic Sans MS", 36F, FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(274, 0);
            label2.Name = "label2";
            label2.Size = new Size(342, 68);
            label2.TabIndex = 1;
            label2.Text = "Le tue ricette";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("SimSun", 18F, FontStyle.Italic, GraphicsUnit.Point);
            label1.Location = new Point(429, 24);
            label1.Name = "label1";
            label1.Size = new Size(94, 24);
            label1.TabIndex = 1;
            label1.Text = "ricette";
            // 
            // Secondi
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.OldLace;
            ClientSize = new Size(876, 513);
            Controls.Add(panel1);
            Controls.Add(btn_chiudi);
            Controls.Add(buttonMostraSecondi);
            Controls.Add(listBoxSecondi);
            Controls.Add(richTextBoxSecondi);
            Name = "Secondi";
            Text = "Secondi";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button btn_chiudi;
        private Button buttonMostraSecondi;
        private ListBox listBoxSecondi;
        private RichTextBox richTextBoxSecondi;
        private Panel panel1;
        private Panel panel2;
        private Label label2;
        private Label label1;
    }
}