﻿namespace ProgettoWinForm
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button2 = new Button();
            label1 = new Label();
            button1 = new Button();
            btnPrimi = new Button();
            btnAntipasti = new Button();
            btnSecondi = new Button();
            btnDolci = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.IndianRed;
            panel1.Controls.Add(button2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(969, 74);
            panel1.TabIndex = 0;
            // 
            // button2
            // 
            button2.BackColor = Color.Bisque;
            button2.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(869, 12);
            button2.Name = "button2";
            button2.Size = new Size(75, 51);
            button2.TabIndex = 8;
            button2.Text = "Chiudi";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Comic Sans MS", 36F, FontStyle.Italic, GraphicsUnit.Point);
            label1.Location = new Point(304, 0);
            label1.Name = "label1";
            label1.Size = new Size(342, 68);
            label1.TabIndex = 1;
            label1.Text = "Le tue ricette";
            // 
            // button1
            // 
            button1.BackColor = Color.Bisque;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Comic Sans MS", 20.25F, FontStyle.Italic, GraphicsUnit.Point);
            button1.Location = new Point(304, 134);
            button1.Name = "button1";
            button1.Size = new Size(350, 60);
            button1.TabIndex = 2;
            button1.Text = "Nuova ricetta";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // btnPrimi
            // 
            btnPrimi.FlatStyle = FlatStyle.Flat;
            btnPrimi.Font = new Font("Times New Roman", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnPrimi.Image = Properties.Resources.Primo2;
            btnPrimi.Location = new Point(248, 247);
            btnPrimi.Name = "btnPrimi";
            btnPrimi.Size = new Size(216, 187);
            btnPrimi.TabIndex = 4;
            btnPrimi.Text = "Primi piatti";
            btnPrimi.TextAlign = ContentAlignment.TopCenter;
            btnPrimi.UseVisualStyleBackColor = true;
            btnPrimi.Click += btnPrimi_Click;
            // 
            // btnAntipasti
            // 
            btnAntipasti.FlatStyle = FlatStyle.Flat;
            btnAntipasti.Font = new Font("Times New Roman", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnAntipasti.ForeColor = Color.White;
            btnAntipasti.Image = Properties.Resources.Antipasti;
            btnAntipasti.Location = new Point(12, 247);
            btnAntipasti.Name = "btnAntipasti";
            btnAntipasti.Size = new Size(216, 187);
            btnAntipasti.TabIndex = 5;
            btnAntipasti.Text = "Antipasti";
            btnAntipasti.TextAlign = ContentAlignment.TopCenter;
            btnAntipasti.UseVisualStyleBackColor = true;
            btnAntipasti.Click += btnAntipasti_Click;
            // 
            // btnSecondi
            // 
            btnSecondi.FlatStyle = FlatStyle.Flat;
            btnSecondi.Font = new Font("Times New Roman", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnSecondi.ForeColor = Color.FloralWhite;
            btnSecondi.Image = Properties.Resources.Secondo;
            btnSecondi.Location = new Point(497, 247);
            btnSecondi.Name = "btnSecondi";
            btnSecondi.Size = new Size(216, 187);
            btnSecondi.TabIndex = 7;
            btnSecondi.Text = "Secondi piatti";
            btnSecondi.TextAlign = ContentAlignment.TopCenter;
            btnSecondi.UseVisualStyleBackColor = true;
            btnSecondi.Click += btnSecondi_Click;
            // 
            // btnDolci
            // 
            btnDolci.FlatStyle = FlatStyle.Flat;
            btnDolci.Font = new Font("Times New Roman", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnDolci.Image = Properties.Resources.tiamisujpeg;
            btnDolci.Location = new Point(733, 247);
            btnDolci.Name = "btnDolci";
            btnDolci.Size = new Size(211, 187);
            btnDolci.TabIndex = 6;
            btnDolci.Text = "Dolci";
            btnDolci.TextAlign = ContentAlignment.TopCenter;
            btnDolci.UseVisualStyleBackColor = true;
            btnDolci.Click += btnDolci_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.OldLace;
            ClientSize = new Size(969, 505);
            Controls.Add(btnSecondi);
            Controls.Add(btnDolci);
            Controls.Add(btnAntipasti);
            Controls.Add(btnPrimi);
            Controls.Add(button1);
            Controls.Add(panel1);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Button button1;
        private Button btnPrimi;
        private Button btnAntipasti;
        private Button btnSecondi;
        private Button btnDolci;
        private Button button2;
    }
}
