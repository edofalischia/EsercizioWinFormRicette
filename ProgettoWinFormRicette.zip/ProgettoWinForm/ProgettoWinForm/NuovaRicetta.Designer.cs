﻿namespace ProgettoWinForm
{
    partial class NuovaRicetta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNome = new RichTextBox();
            txtIngredienti = new RichTextBox();
            txtTempoPrep = new RichTextBox();
            button1 = new Button();
            button2 = new Button();
            panel1 = new Panel();
            panel2 = new Panel();
            label7 = new Label();
            label1 = new Label();
            txtPreparazione = new RichTextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            comboBox1 = new ComboBox();
            label6 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // txtNome
            // 
            txtNome.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtNome.Location = new Point(74, 145);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(180, 41);
            txtNome.TabIndex = 0;
            txtNome.Text = "";
            // 
            // txtIngredienti
            // 
            txtIngredienti.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtIngredienti.Location = new Point(313, 169);
            txtIngredienti.Name = "txtIngredienti";
            txtIngredienti.Size = new Size(200, 202);
            txtIngredienti.TabIndex = 2;
            txtIngredienti.Text = "";
            // 
            // txtTempoPrep
            // 
            txtTempoPrep.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtTempoPrep.Location = new Point(74, 256);
            txtTempoPrep.Name = "txtTempoPrep";
            txtTempoPrep.Size = new Size(180, 45);
            txtTempoPrep.TabIndex = 4;
            txtTempoPrep.Text = "";
            // 
            // button1
            // 
            button1.BackColor = Color.Bisque;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(847, 174);
            button1.Name = "button1";
            button1.Size = new Size(82, 58);
            button1.TabIndex = 6;
            button1.Text = "Salva";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Bisque;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(847, 292);
            button2.Name = "button2";
            button2.Size = new Size(82, 53);
            button2.TabIndex = 7;
            button2.Text = "Chiudi";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Tan;
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(981, 74);
            panel1.TabIndex = 8;
            // 
            // panel2
            // 
            panel2.BackColor = Color.IndianRed;
            panel2.Controls.Add(label7);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(981, 74);
            panel2.TabIndex = 2;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Comic Sans MS", 36F, FontStyle.Italic, GraphicsUnit.Point);
            label7.Location = new Point(304, 0);
            label7.Name = "label7";
            label7.Size = new Size(342, 68);
            label7.TabIndex = 1;
            label7.Text = "Le tue ricette";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("SimSun", 18F, FontStyle.Italic, GraphicsUnit.Point);
            label1.Location = new Point(429, 24);
            label1.Name = "label1";
            label1.Size = new Size(94, 24);
            label1.TabIndex = 1;
            label1.Text = "ricette";
            // 
            // txtPreparazione
            // 
            txtPreparazione.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtPreparazione.Location = new Point(573, 169);
            txtPreparazione.Name = "txtPreparazione";
            txtPreparazione.Size = new Size(200, 202);
            txtPreparazione.TabIndex = 9;
            txtPreparazione.Text = "";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(74, 123);
            label2.Name = "label2";
            label2.Size = new Size(171, 19);
            label2.TabIndex = 11;
            label2.Text = "Inserisi il nome della ricetta";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(74, 234);
            label3.Name = "label3";
            label3.Size = new Size(207, 19);
            label3.TabIndex = 12;
            label3.Text = "Inserisci il tempo di preparazione";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(313, 147);
            label4.Name = "label4";
            label4.Size = new Size(140, 19);
            label4.TabIndex = 13;
            label4.Text = "Inserisci gli ingredienti";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(573, 147);
            label5.Name = "label5";
            label5.Size = new Size(147, 19);
            label5.TabIndex = 14;
            label5.Text = "Inserisi la preparazione";
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(74, 374);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 27);
            comboBox1.TabIndex = 15;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(74, 352);
            label6.Name = "label6";
            label6.Size = new Size(131, 19);
            label6.TabIndex = 16;
            label6.Text = "Inserisci la categoria";
            // 
            // NuovaRicetta
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.OldLace;
            ClientSize = new Size(981, 478);
            Controls.Add(label6);
            Controls.Add(comboBox1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtPreparazione);
            Controls.Add(panel1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(txtTempoPrep);
            Controls.Add(txtIngredienti);
            Controls.Add(txtNome);
            Name = "NuovaRicetta";
            Text = "NuovaRicetta";
            Load += NuovaRicetta_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox txtNome;
        private RichTextBox txtIngredienti;
        private RichTextBox txtTempoPrep;
        private Button button1;
        private Button button2;
        private Panel panel1;
        private Label label1;
        private RichTextBox txtPreparazione;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private ComboBox comboBox1;
        private Label label6;
        private Panel panel2;
        private Label label7;
    }
}