﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Reflection.Metadata.Ecma335;

namespace ProgettoWinForm
{
    public partial class NuovaRicetta : Form
    {
        private Form1 form1;

        public List<Ricetta> Listaricette { get; private set; } = new List<Ricetta>();

        public NuovaRicetta(Form1 form1)
        {
            InitializeComponent();
            this.form1 = form1;
            form1.Visible = false;
        }

        private void NuovaRicetta_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Antipasti");
            comboBox1.Items.Add("Primi piatti");
            comboBox1.Items.Add("Secondi piatti");
            comboBox1.Items.Add("Dolci");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            form1.Visible = true;
            this.Close();
        }

        public void button1_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text.Trim();
            string tempoPrep = txtTempoPrep.Text.Trim();
            string ingredienti = txtIngredienti.Text.Trim();
            string preparazione = txtPreparazione.Text.Trim();
            string categoria = comboBox1.SelectedItem?.ToString();
            // Verifica che tutti i campi siano compilati
            if (string.IsNullOrWhiteSpace(nome) || string.IsNullOrWhiteSpace(ingredienti) || string.IsNullOrWhiteSpace(tempoPrep)
                || string.IsNullOrWhiteSpace(preparazione) || string.IsNullOrWhiteSpace(categoria))
            {
                MessageBox.Show("Tutti i campi sono obbligatori!", "Errore", MessageBoxButtons.OK);
                return;
            }
            // Carica lo storico delle ricette già salvate
            CaricaRicetteDaFile();
            // Controlla se una ricetta con lo stesso nome esiste già
            if (Listaricette.Any(r => r.Nome.Equals(nome, StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show("Esiste già una ricetta con questo nome!", "Errore", MessageBoxButtons.OK);
                return;
            }
            // Aggiungi la nuova ricetta
            Ricetta nuovaRicetta = new Ricetta
            {
                Nome = nome,
                TempoPrep = tempoPrep,
                Ingredienti = ingredienti,
                Preparazione = preparazione,
                Categoria = categoria
            };
            Listaricette.Add(nuovaRicetta);
            // Salva tutte le ricette (nuova e storiche)
            SalvaRicetteSuFile();
            // Conferma all'utente
            MessageBox.Show("Ricetta salvata con successo!", "Successo", MessageBoxButtons.OK);
            // Pulisce i campi dopo l'inserimento
            txtNome.Clear();
            txtTempoPrep.Clear();
            txtIngredienti.Clear();
            txtPreparazione.Clear();
            comboBox1.Text = "";
        }
        private void SalvaRicetteSuFile()
        {
            string filePath = @"C:\Users\edoar\Desktop\ProgettoWinFormRicette\ProgettoWinForm\ricette.json";
            string jsonString = JsonSerializer.Serialize(Listaricette, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(filePath, jsonString);
        }
        private void CaricaRicetteDaFile()
        {
            string filePath = @"C:\Users\edoar\Desktop\ProgettoWinFormRicette\ProgettoWinForm\ricette.json";
            if (File.Exists(filePath))
            {
                string jsonString = File.ReadAllText(filePath);
                Listaricette = JsonSerializer.Deserialize<List<Ricetta>>(jsonString) ?? new List<Ricetta>();
            }
            else
            {
                // Se il file non esiste, inizializza una lista vuota
                Listaricette = new List<Ricetta>();
            }
        }
        
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        public static List<Ricetta> OttieniRicette()
        {
            string filePath = @"C:\Users\edoar\Desktop\ProgettoWinFormRicette\ProgettoWinForm\ricette.json";
            if (File.Exists(filePath))
            {
                string jsonString = File.ReadAllText(filePath);
                return JsonSerializer.Deserialize<List<Ricetta>>(jsonString) ?? new List<Ricetta>();
            }
            return new List<Ricetta>();
        }
        public static List<string> FiltraNomiRicette(List<Ricetta> ricette)
        {
            return ricette?.Select(r => r.Nome).ToList() ?? new List<string>();
        }
    }
    public class Ricetta
    {
        public string Nome { get; set; }
        public string TempoPrep { get; set; }
        public string Ingredienti { get; set; }
        public string Preparazione { get; set; }
        public string Categoria { get; set; }

        public Ricetta() { }

        public Ricetta(string nome, string tempoPrep, string ingredienti, string preparazione, string categoria)
        {
            Nome = nome;
            TempoPrep = tempoPrep;
            Ingredienti = ingredienti;
            Preparazione = preparazione;
            Categoria = categoria;
        }

        public override string ToString()
        {
            return $"Nome: {Nome} \nTempo di preparazione: {TempoPrep} \nIngredienti: {Ingredienti} " +
                $"\nPreparazione: {Preparazione} \nCategoria: {Categoria}";
        }

    }
}
