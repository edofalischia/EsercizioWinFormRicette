﻿namespace ProgettoWinForm
{
    partial class Dolci
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            panel2 = new Panel();
            label2 = new Label();
            label1 = new Label();
            btn_chiudi = new Button();
            buttonMostraDolci = new Button();
            listBoxDolci = new ListBox();
            richTextBoxDolci = new RichTextBox();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Tan;
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(857, 74);
            panel1.TabIndex = 22;
            // 
            // panel2
            // 
            panel2.BackColor = Color.IndianRed;
            panel2.Controls.Add(label2);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(857, 74);
            panel2.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Comic Sans MS", 36F, FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(258, 6);
            label2.Name = "label2";
            label2.Size = new Size(342, 68);
            label2.TabIndex = 1;
            label2.Text = "Le tue ricette";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("SimSun", 18F, FontStyle.Italic, GraphicsUnit.Point);
            label1.Location = new Point(429, 24);
            label1.Name = "label1";
            label1.Size = new Size(94, 24);
            label1.TabIndex = 1;
            label1.Text = "ricette";
            // 
            // btn_chiudi
            // 
            btn_chiudi.BackColor = Color.Bisque;
            btn_chiudi.FlatStyle = FlatStyle.Flat;
            btn_chiudi.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btn_chiudi.Location = new Point(167, 416);
            btn_chiudi.Name = "btn_chiudi";
            btn_chiudi.Size = new Size(74, 66);
            btn_chiudi.TabIndex = 26;
            btn_chiudi.Text = "Chiudi";
            btn_chiudi.UseVisualStyleBackColor = false;
            btn_chiudi.Click += btn_chiudi_Click;
            // 
            // buttonMostraDolci
            // 
            buttonMostraDolci.BackColor = Color.Bisque;
            buttonMostraDolci.FlatStyle = FlatStyle.Flat;
            buttonMostraDolci.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            buttonMostraDolci.Location = new Point(30, 416);
            buttonMostraDolci.Name = "buttonMostraDolci";
            buttonMostraDolci.Size = new Size(74, 66);
            buttonMostraDolci.TabIndex = 25;
            buttonMostraDolci.Text = "Mostra ricetta";
            buttonMostraDolci.UseVisualStyleBackColor = false;
            buttonMostraDolci.Click += buttonMostraDolci_Click;
            // 
            // listBoxDolci
            // 
            listBoxDolci.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            listBoxDolci.FormattingEnabled = true;
            listBoxDolci.ItemHeight = 19;
            listBoxDolci.Location = new Point(57, 101);
            listBoxDolci.Name = "listBoxDolci";
            listBoxDolci.Size = new Size(155, 289);
            listBoxDolci.TabIndex = 24;
            // 
            // richTextBoxDolci
            // 
            richTextBoxDolci.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
            richTextBoxDolci.Location = new Point(319, 101);
            richTextBoxDolci.Name = "richTextBoxDolci";
            richTextBoxDolci.Size = new Size(503, 368);
            richTextBoxDolci.TabIndex = 23;
            richTextBoxDolci.Text = "";
            // 
            // Dolci
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.OldLace;
            ClientSize = new Size(857, 494);
            Controls.Add(btn_chiudi);
            Controls.Add(buttonMostraDolci);
            Controls.Add(listBoxDolci);
            Controls.Add(richTextBoxDolci);
            Controls.Add(panel1);
            Name = "Dolci";
            Text = "Dolci";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Label label2;
        private Label label1;
        private Button btn_chiudi;
        private Button buttonMostraDolci;
        private ListBox listBoxDolci;
        private RichTextBox richTextBoxDolci;
    }
}