﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgettoWinForm
{
    public partial class Primi : Form
    {
        private Form1 form1;
        public Primi(Form1 form1)
        {
            InitializeComponent();
            var nomiPrimi = NuovaRicetta.FiltraNomiRicette(NuovaRicetta.OttieniRicette().Where(r => r.Categoria == "Primi piatti").ToList());
            foreach (var nome in nomiPrimi)
            {
                if (!listBoxPrimi.Items.Contains(nome))
                {
                    listBoxPrimi.Items.Add(nome);
                }
            }
            this.form1 = form1;
            form1.Visible = false;
        }

        private void Primi_Load(object sender, EventArgs e)
        {

        }

        private void buttonMostraPrimi_Click(object sender, EventArgs e)
        {
            if (listBoxPrimi.SelectedItem is string nomeRicettaSelezionata)
            {
                var ricette = NuovaRicetta.OttieniRicette();
                var ricettaSelezionata = ricette.FirstOrDefault(r => r.Nome == nomeRicettaSelezionata);
                if (ricettaSelezionata != null)
                {
                    richTextBoxPrimi.Clear();
                    richTextBoxPrimi.AppendText(ricettaSelezionata.ToString());
                }
                else
                {
                    MessageBox.Show("Ricetta non trovata.");
                }
            }
            else
            {
                MessageBox.Show("Seleziona una ricetta.");
            }
        }

        private void btn_chiudi_Click(object sender, EventArgs e)
        {
            this.Close();
            form1.Visible = true;
        }
    }
}
