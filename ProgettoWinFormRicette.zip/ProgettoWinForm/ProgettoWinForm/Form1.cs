namespace ProgettoWinForm
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            NuovaRicetta apriForm = new NuovaRicetta(this);
            apriForm.ShowDialog();
        }

        private void btnRicettaSalvata1_Click(object sender, EventArgs e)
        {

        }

        private void btnAntipasti_Click(object sender, EventArgs e)
        {
            Antipasti apriForm = new Antipasti(this);
            apriForm.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPrimi_Click(object sender, EventArgs e)
        {
            Primi apriForm = new Primi(this);
            apriForm.ShowDialog();
        }

        private void btnSecondi_Click(object sender, EventArgs e)
        {
            Secondi apriForm = new Secondi(this);
            apriForm.ShowDialog();
        }

        private void btnDolci_Click(object sender, EventArgs e)
        {
            Dolci apriForm = new Dolci(this);
            apriForm.ShowDialog();
        }
    }
}

